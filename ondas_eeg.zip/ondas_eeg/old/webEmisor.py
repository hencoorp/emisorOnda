""" import asyncio
import websockets
import datetime

async def send_data():
    uri = "wss://kg85v3-8765.csb.app"  # URL de tu servidor en CodeSandbox

    async with websockets.connect(uri) as websocket:
        try:
            while True:
                await asyncio.sleep(1)
                # Obtener la hora y fecha actual
                current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                # Crear el mensaje con la hora y fecha actual
                data_to_send = f"{current_time}: Enviando dato al servidor"
                # Enviar el mensaje al servidor
                await websocket.send(data_to_send)
                print(f"Datos enviados: {data_to_send}")

        except KeyboardInterrupt:
            print("Interrupción por teclado. Deteniendo la transmisión de datos.")

asyncio.get_event_loop().run_until_complete(send_data())
 """


import asyncio
import websockets
import datetime

async def send_data():
    uri = "wss://kg85v3-8765.csb.app"  # URL de tu servidor en CodeSandbox

    while True:
        try:
            async with websockets.connect(uri) as websocket:
                while True:
                    # Obtener la hora y fecha actual
                    current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    # Crear el mensaje con la hora y fecha actual
                    data_to_send = f"{current_time}: Dato enviado desde sensor"
                    # Enviar el mensaje al servidor
                    await websocket.send(data_to_send)
                    print(f"Datos enviados: {data_to_send}")

                    # Esperar un segundo antes de enviar el próximo mensaje
                    await asyncio.sleep(1)

        except websockets.exceptions.ConnectionClosedError as e:
            print(f"Se cerró la conexión. Reconectando...")

        except KeyboardInterrupt:
            print("Interrupción por teclado. Deteniendo la transmisión de datos.")
            break

asyncio.get_event_loop().run_until_complete(send_data())
