import time
import numpy as np
import matplotlib.pyplot as plt
from brainflow.board_shim import BoardShim, BrainFlowInputParams, LogLevels, BoardIds

def main():
    BoardShim.enable_dev_board_logger()  # Habilitar el registro de la placa de desarrollo
    params = BrainFlowInputParams()  # Crear un objeto para configurar los parámetros de entrada
    # params.serial_port = "COM3"  # Configurar el puerto serial COM3 para la conexión con la placa Cyton

    # Crear un objeto de la placa sintética con los parámetros configurados
    board = BoardShim(BoardIds.SYNTHETIC_BOARD.value, params)

    # Preparar la sesión de la placa para la adquisición de datos
    board.prepare_session()
    board.start_stream()  # Iniciar la transmisión de datos desde la placa

    plt.ion()  # Habilitar el modo interactivo de matplotlib
    fig, axs = plt.subplots(4, 1, figsize=(10, 10))  # Crear una figura y 4 subplots (uno para cada onda)
    lines = [ax.plot([], [])[0] for ax in axs]  # Inicializar una línea vacía para cada subplot

    # Etiquetas para las ondas cerebrales
    wave_names = ['Delta (0.5-4 Hz)', 'Theta (4-8 Hz)', 'Alpha (8-13 Hz)', 'Beta (13-30 Hz)']
    for ax, wave_name in zip(axs, wave_names):
        ax.set_title(wave_name)
        ax.set_xlabel('Tiempo (s)')
        ax.set_ylabel('Amplitud')

    # Ajustar el espaciado entre los subplots
    plt.subplots_adjust(hspace=0.5)  # Ajustar el espacio vertical entre los subplots

    try:
        while True:  # Bucle infinito para obtener datos periódicamente
            time.sleep(1)  # Esperar 1 segundo
            data = board.get_board_data()  # Obtener los datos de la placa
            eeg_channels = BoardShim.get_eeg_channels(BoardIds.SYNTHETIC_BOARD.value)  # Obtener los canales de EEG
            eeg_data = data[eeg_channels, :]  # Extraer los datos de los canales de EEG

            # Simulación de las diferentes ondas cerebrales (para fines de demostración)
            # En un caso real, deberías filtrar y separar estas ondas de los datos de EEG
            waves = [eeg_data[0], eeg_data[1], eeg_data[2], eeg_data[3]]  # Supongamos que tenemos 4 canales

            for line, wave, ax in zip(lines, waves, axs):
                line.set_xdata(np.arange(wave.shape[0]))
                line.set_ydata(wave)
                ax.relim()  # Recalcular los límites del eje
                ax.autoscale_view()  # Autoajustar la vista

            fig.canvas.draw()  # Dibujar la figura
            fig.canvas.flush_events()  # Actualizar los eventos de la figura

    except KeyboardInterrupt:
        # Detener la transmisión y liberar los recursos cuando se interrumpe el bucle
        print("Interrupción por teclado. Deteniendo la transmisión de datos.")

    finally:
        board.stop_stream()  # Detener la transmisión de datos
        board.release_session()  # Liberar los recursos de la sesión de la placa

if __name__ == "__main__":
    main()
