# client.py
import asyncio
import websockets

async def send_data():
    uri = "wss://connectar.ngrok-agent.com:80"  # Usar el túnel proporcionado por ngrok

    async with websockets.connect(uri) as websocket:
        try:
            while True:
                await asyncio.sleep(1)
                # Aquí puedes enviar tus datos al servidor si es necesario
                await websocket.send("Datos de ejemplo desde el cliente")

        except KeyboardInterrupt:
            print("Interrupción por teclado. Deteniendo la transmisión de datos.")

asyncio.get_event_loop().run_until_complete(send_data())
