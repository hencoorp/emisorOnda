# client.py
import asyncio
import websockets

async def send_data():
    uri = "ws://localhost:5556"

    async with websockets.connect(uri) as websocket:
        try:
            while True:
                await asyncio.sleep(1)
                # Enviar datos de ejemplo al servidor
                data_to_send = "Datos de ejemplo desde el cliente"
                await websocket.send(data_to_send)
                print(f"Datos enviados: {data_to_send}")

        except KeyboardInterrupt:
            print("Interrupción por teclado. Deteniendo la transmisión de datos.")

asyncio.get_event_loop().run_until_complete(send_data())
