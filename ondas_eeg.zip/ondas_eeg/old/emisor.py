import time
from brainflow.board_shim import BoardShim, BrainFlowInputParams, LogLevels, BoardIds

def main():
    BoardShim.enable_dev_board_logger()  # Habilitar el registro de la placa de desarrollo
    params = BrainFlowInputParams()  # Crear un objeto para configurar los parámetros de entrada
    # params.serial_port = "COM3"  # Configurar el puerto serial COM3 para la conexión con la placa Cyton

    # Crear un objeto de la placa sintética con los parámetros configurados
    board = BoardShim(BoardIds.SYNTHETIC_BOARD.value, params)

    # Preparar la sesión de la placa para la adquisición de datos
    board.prepare_session()
    board.start_stream()  # Iniciar la transmisión de datos desde la placa

    try:
        while True:  # Bucle infinito para obtener datos periódicamente
            time.sleep(1)  # Esperar 1 segundo
            data = board.get_board_data()  # Obtener los datos de la placa
            print(data)  # Imprimir los datos obtenidos

    except KeyboardInterrupt:
        # Detener la transmisión y liberar los recursos cuando se interrumpe el bucle
        print("Interrupción por teclado. Deteniendo la transmisión de datos.")

    finally:
        board.stop_stream()  # Detener la transmisión de datos
        board.release_session()  # Liberar los recursos de la sesión de la placa

if __name__ == "__main__":
    main()


