import time
import numpy as np
import socket
from brainflow.board_shim import BoardShim, BrainFlowInputParams, LogLevels, BoardIds

def main():
    BoardShim.enable_dev_board_logger()
    params = BrainFlowInputParams()
    board = BoardShim(BoardIds.SYNTHETIC_BOARD.value, params)
    board.prepare_session()
    board.start_stream()

    server_address = ('192.168.10.62', 5556)  # Dirección del túnel SSH
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect(server_address)

    try:
        while True:
            time.sleep(1)
            data = board.get_board_data()
            eeg_channels = BoardShim.get_eeg_channels(BoardIds.SYNTHETIC_BOARD.value)
            eeg_data = data[eeg_channels, :]

            # Convertir los datos a un formato adecuado para enviar
            data_to_send = eeg_data.tolist()
            sock.sendall(bytes(str(data_to_send), 'utf-8'))

    except KeyboardInterrupt:
        print("Interrupción por teclado. Deteniendo la transmisión de datos.")
    
    finally:
        board.stop_stream()
        board.release_session()
        sock.close()

if __name__ == "__main__":
    main()
